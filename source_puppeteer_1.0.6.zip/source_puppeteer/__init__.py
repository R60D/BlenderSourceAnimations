# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Source Puppeteer",
    "description": "Allows for modified rigs to puppet non-modified source engine armatures. Note! the Rigs have to share bone names.",
    "author": "R60D",
    "version": (1, 0, 6),
    "blender": (3, 0, 0),
    "location": "Finland",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
source_puppeteer = {
    "main": "", 
    "active": None, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Source Puppeteer
def new_function():
    try:
        for_node_5B17E = 0
        for_node_index_5B17E = 0
        for for_node_index_5B17E, for_node_5B17E in enumerate(bpy.context.selected_objects):
            if bpy.context.active_object != for_node_5B17E:
                for_node_C9531 = 0
                for_node_index_C9531 = 0
                for for_node_index_C9531, for_node_C9531 in enumerate(for_node_5B17E.pose.bones):
                    for_node_BEFAF = 0
                    for_node_index_BEFAF = 0
                    for for_node_index_BEFAF, for_node_BEFAF in enumerate(for_node_C9531.constraints):
                        bpy.ops.constraint.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',constraint=sn_cast_string(for_node_BEFAF),owner=sn_cast_string(for_node_C9531),report=False,)
                    function_return_81990 = childof(for_node_C9531.constraints, for_node_C9531.name, bpy.context.active_object, )
                    if r"bip_pelvis" == for_node_C9531.name:
                        function_return_3713A = copy_location(for_node_C9531.constraints, bpy.context.active_object, for_node_C9531.name, )
                    else:
                        pass
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function New Function")

def inverse_array():
    try:
        for_node_DD00C = 0
        for_node_index_DD00C = 0
        for for_node_index_DD00C, for_node_DD00C in enumerate(bpy.context.selected_objects):
            if bpy.context.active_object != for_node_DD00C:
                for_node_3E8AC = 0
                for_node_index_3E8AC = 0
                for for_node_index_3E8AC, for_node_3E8AC in enumerate(for_node_DD00C.data.bones):
                    for_node_3E8AC.use_inherit_rotation=False
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function Inverse_array")

def inverse_bones():
    try:
        source_puppeteer["main"] = bpy.context.active_object.name
        for_node_97CD6 = 0
        for_node_index_97CD6 = 0
        for for_node_index_97CD6, for_node_97CD6 in enumerate(bpy.context.selected_objects):
            bpy.context.view_layer.objects.active=for_node_97CD6
            if bpy.data.objects[source_puppeteer["main"]] != for_node_97CD6:
                for_node_FCD56 = 0
                for_node_index_FCD56 = 0
                for for_node_index_FCD56, for_node_FCD56 in enumerate(for_node_97CD6.pose.bones):
                    function_return_D6A75 = inverse_to_bone(for_node_FCD56, )
            else:
                pass
        bpy.context.view_layer.objects.active=bpy.data.objects[source_puppeteer["main"]]
    except Exception as exc:
        print(str(exc) + " | Error in function Inverse_bones")

def fix_position_and_pose():
    try:
        for_node_6DE05 = 0
        for_node_index_6DE05 = 0
        for for_node_index_6DE05, for_node_6DE05 in enumerate(bpy.context.selected_objects):
            run_function_on_7BA10 = for_node_6DE05.select_set(state=for_node_6DE05.type=="ARMATURE", view_layer=None, )
            if bpy.context.active_object.type=="MESH":
                print(r"DESELECT MESHES PLEASE")
            else:
                source_puppeteer["active"] = bpy.context.active_object
                run_function_on_0E788 = bpy.context.active_object.select_set(state=False, view_layer=None, )
                bpy.ops.object.location_clear('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',clear_delta=True,)
                bpy.ops.object.rotation_clear('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',clear_delta=True,)
                bpy.ops.object.scale_clear('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',clear_delta=True,)
                run_function_on_067D3 = source_puppeteer["active"].select_set(state=True, view_layer=None, )
                bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"POSE", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
                bpy.ops.pose.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
                bpy.ops.pose.transforms_clear('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
    except Exception as exc:
        print(str(exc) + " | Error in function Fix position and pose")

def childof(constraint, sub_target_str, target_obj, ):
    try:
        run_function_on_03233 = sn_cast_blend_data(constraint).new(type=sn_cast_enum(r"CHILD_OF", [("CAMERA_SOLVER","Camera Solver",""),("FOLLOW_TRACK","Follow Track",""),("OBJECT_SOLVER","Object Solver",""),("COPY_LOCATION","Copy Location","Copy the location of a target (with an optional offset), so that they move together"),("COPY_ROTATION","Copy Rotation","Copy the rotation of a target (with an optional offset), so that they rotate together"),("COPY_SCALE","Copy Scale","Copy the scale factors of a target (with an optional offset), so that they are scaled by the same amount"),("COPY_TRANSFORMS","Copy Transforms","Copy all the transformations of a target, so that they move together"),("LIMIT_DISTANCE","Limit Distance","Restrict movements to within a certain distance of a target (at the time of constraint evaluation only)"),("LIMIT_LOCATION","Limit Location","Restrict movement along each axis within given ranges"),("LIMIT_ROTATION","Limit Rotation","Restrict rotation along each axis within given ranges"),("LIMIT_SCALE","Limit Scale","Restrict scaling along each axis with given ranges"),("MAINTAIN_VOLUME","Maintain Volume","Compensate for scaling one axis by applying suitable scaling to the other two axes"),("TRANSFORM","Transformation","Use one transform property from target to control another (or same) property on owner"),("TRANSFORM_CACHE","Transform Cache","Look up the transformation matrix from an external file"),("CLAMP_TO","Clamp To","Restrict movements to lie along a curve by remapping location along curve's longest axis"),("DAMPED_TRACK","Damped Track","Point towards a target by performing the smallest rotation necessary"),("IK","Inverse Kinematics","Control a chain of bones by specifying the endpoint target (Bones only)"),("LOCKED_TRACK","Locked Track","Rotate around the specified ('locked') axis to point towards a target"),("SPLINE_IK","Spline IK","Align chain of bones along a curve (Bones only)"),("STRETCH_TO","Stretch To","Stretch along Y-Axis to point towards a target"),("TRACK_TO","Track To","Legacy tracking constraint prone to twisting artifacts"),("ACTION","Action","Use transform property of target to look up pose for owner from an Action"),("ARMATURE","Armature","Apply weight-blended transformation from multiple bones like the Armature modifier"),("CHILD_OF","Child Of","Make target the 'detachable' parent of owner"),("FLOOR","Floor","Use position (and optionally rotation) of target to define a 'wall' or 'floor' that the owner can not cross"),("FOLLOW_PATH","Follow Path","Use to animate an object/bone following a path"),("PIVOT","Pivot","Change pivot point for transforms (buggy)"),("SHRINKWRAP","Shrinkwrap","Restrict movements to surface of target mesh"),]), )
        sn_cast_blend_data(run_function_on_03233).subtarget = sn_cast_string(sub_target_str)
        sn_cast_blend_data(run_function_on_03233).target = sn_cast_blend_data(target_obj)
        sn_cast_blend_data(run_function_on_03233).use_location_x = False
        sn_cast_blend_data(run_function_on_03233).use_location_y = False
        sn_cast_blend_data(run_function_on_03233).use_location_z = False
        sn_cast_blend_data(run_function_on_03233).use_scale_x = False
        sn_cast_blend_data(run_function_on_03233).use_scale_y = False
        sn_cast_blend_data(run_function_on_03233).use_scale_z = False
    except Exception as exc:
        print(str(exc) + " | Error in function ChildOf")

def copy_location(constraint, target, subtarget, ):
    try:
        run_function_on_38933 = sn_cast_blend_data(constraint).new(type=sn_cast_enum(r"COPY_LOCATION", [("CAMERA_SOLVER","Camera Solver",""),("FOLLOW_TRACK","Follow Track",""),("OBJECT_SOLVER","Object Solver",""),("COPY_LOCATION","Copy Location","Copy the location of a target (with an optional offset), so that they move together"),("COPY_ROTATION","Copy Rotation","Copy the rotation of a target (with an optional offset), so that they rotate together"),("COPY_SCALE","Copy Scale","Copy the scale factors of a target (with an optional offset), so that they are scaled by the same amount"),("COPY_TRANSFORMS","Copy Transforms","Copy all the transformations of a target, so that they move together"),("LIMIT_DISTANCE","Limit Distance","Restrict movements to within a certain distance of a target (at the time of constraint evaluation only)"),("LIMIT_LOCATION","Limit Location","Restrict movement along each axis within given ranges"),("LIMIT_ROTATION","Limit Rotation","Restrict rotation along each axis within given ranges"),("LIMIT_SCALE","Limit Scale","Restrict scaling along each axis with given ranges"),("MAINTAIN_VOLUME","Maintain Volume","Compensate for scaling one axis by applying suitable scaling to the other two axes"),("TRANSFORM","Transformation","Use one transform property from target to control another (or same) property on owner"),("TRANSFORM_CACHE","Transform Cache","Look up the transformation matrix from an external file"),("CLAMP_TO","Clamp To","Restrict movements to lie along a curve by remapping location along curve's longest axis"),("DAMPED_TRACK","Damped Track","Point towards a target by performing the smallest rotation necessary"),("IK","Inverse Kinematics","Control a chain of bones by specifying the endpoint target (Bones only)"),("LOCKED_TRACK","Locked Track","Rotate around the specified ('locked') axis to point towards a target"),("SPLINE_IK","Spline IK","Align chain of bones along a curve (Bones only)"),("STRETCH_TO","Stretch To","Stretch along Y-Axis to point towards a target"),("TRACK_TO","Track To","Legacy tracking constraint prone to twisting artifacts"),("ACTION","Action","Use transform property of target to look up pose for owner from an Action"),("ARMATURE","Armature","Apply weight-blended transformation from multiple bones like the Armature modifier"),("CHILD_OF","Child Of","Make target the 'detachable' parent of owner"),("FLOOR","Floor","Use position (and optionally rotation) of target to define a 'wall' or 'floor' that the owner can not cross"),("FOLLOW_PATH","Follow Path","Use to animate an object/bone following a path"),("PIVOT","Pivot","Change pivot point for transforms (buggy)"),("SHRINKWRAP","Shrinkwrap","Restrict movements to surface of target mesh"),]), )
        run_function_on_38933.target = sn_cast_blend_data(target)
        run_function_on_38933.subtarget = sn_cast_string(subtarget)
        run_function_on_38933.target_space = sn_cast_enum(r"POSE", [("WORLD","World Space","The transformation of the target is evaluated relative to the world coordinate system"),("CUSTOM","Custom Space","The transformation of the target is evaluated relative to a custom object/bone/vertex group"),("POSE","Pose Space","The transformation of the target is only evaluated in the Pose Space, the target armature object transformation is ignored"),("LOCAL_WITH_PARENT","Local With Parent","The transformation of the target bone is evaluated relative to its rest pose local coordinate system, thus including the parent-induced transformation"),("LOCAL","Local Space","The transformation of the target is evaluated relative to its local coordinate system"),("LOCAL_OWNER_ORIENT","Local Space (Owner Orientation)","The transformation of the target bone is evaluated relative to its local coordinate system, followed by a correction for the difference in target and owner rest pose orientations. When applied as local transform to the owner produces the same global motion as the target if the parents are still in rest pose"),])
        run_function_on_38933.owner_space = sn_cast_enum(r"WORLD", [("WORLD","World Space","The constraint is applied relative to the world coordinate system"),("CUSTOM","Custom Space","The constraint is applied in local space of a custom object/bone/vertex group"),("POSE","Pose Space","The constraint is applied in Pose Space, the object transformation is ignored"),("LOCAL_WITH_PARENT","Local With Parent","The constraint is applied relative to the rest pose local coordinate system of the bone, thus including the parent-induced transformation"),("LOCAL","Local Space","The constraint is applied relative to the local coordinate system of the object"),])
    except Exception as exc:
        print(str(exc) + " | Error in function Copy location")

def inverse_to_bone(bone, ):
    try:
        try: exec((r"bpy.context.active_object.pose.bones['" + bone.name + r"'].constraints[" + r"0" + r"].set_inverse_pending = True"))
        except Exception as exc: sn_handle_script_line_exception(exc, (r"bpy.context.active_object.pose.bones['" + bone.name + r"'].constraints[" + r"0" + r"].set_inverse_pending = True"))
    except Exception as exc:
        print(str(exc) + " | Error in function Inverse to bone")

def inverse_fix_on_selected():
    try:
        for_node_D6081 = 0
        for_node_index_D6081 = 0
        for for_node_index_D6081, for_node_D6081 in enumerate(bpy.context.selected_objects):
            if for_node_D6081.type=="ARMATURE":
                for_node_28F1E = 0
                for_node_index_28F1E = 0
                for for_node_index_28F1E, for_node_28F1E in enumerate(for_node_D6081.data.bones):
                    function_return_DD1B1 = inverse_to_bone(for_node_28F1E, )
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function Inverse_fix_On_selected")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def lockker():
    try:
        for_node_5001F = 0
        for_node_index_5001F = 0
        for for_node_index_5001F, for_node_5001F in enumerate(bpy.context.selected_objects):
            if for_node_5001F == bpy.context.active_object:
                for_node_5001F.lock_rotation = (True, True, True)
                for_node_5001F.lock_scale = (True, True, True)
            else:
                for_node_5001F.lock_location = (True, True, True)
                for_node_5001F.lock_rotation = (True, True, True)
                for_node_5001F.lock_scale = (True, True, True)
    except Exception as exc:
        print(str(exc) + " | Error in function Lockker")


###############   EVALUATED CODE
#######   Source Puppeteer
def sn_prepend_menu_8E3C2(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.puppet_master",text=r"Puppet",emboss=True,depress=True,icon_value=0)
    except Exception as exc:
        print(str(exc) + " | Error in View3D Mt Object when adding to menu")


class SNA_OT_Puppet_Master(bpy.types.Operator):
    bl_idname = "sna.puppet_master"
    bl_label = "Puppet Master"
    bl_description = "Select the main rig as active and others as puppets"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_C27EC = fix_position_and_pose()
            function_return_B64C9 = new_function()
            function_return_22D36 = inverse_array()
            bpy.app.timers.register(inverse_bones, first_interval=0.5)
            function_return_75B1C = lockker()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Puppet Master")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Puppet Master")
        return self.execute(context)


class SNA_OT_Inverse_Fix(bpy.types.Operator):
    bl_idname = "sna.inverse_fix"
    bl_label = "Inverse fix"
    bl_description = "Fixes a puppet that has desynced from the main rig"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_7C888 = inverse_fix_on_selected()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Inverse fix")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Inverse fix")
        return self.execute(context)

def sn_prepend_menu_2D2B3(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.inverse_fix",text=r"Inverse_fix",emboss=True,depress=False,icon_value=0)
    except Exception as exc:
        print(str(exc) + " | Error in View3D Mt Object when adding to menu")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.source_puppeteer_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.source_puppeteer_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.source_puppeteer_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    pass

def sn_unregister_properties():
    pass


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Puppet_Master)
    bpy.utils.register_class(SNA_OT_Inverse_Fix)
    bpy.types.VIEW3D_MT_object.prepend(sn_prepend_menu_8E3C2)
    bpy.types.VIEW3D_MT_object.prepend(sn_prepend_menu_2D2B3)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.VIEW3D_MT_object.remove(sn_prepend_menu_2D2B3)
    bpy.types.VIEW3D_MT_object.remove(sn_prepend_menu_8E3C2)
    bpy.utils.unregister_class(SNA_OT_Inverse_Fix)
    bpy.utils.unregister_class(SNA_OT_Puppet_Master)