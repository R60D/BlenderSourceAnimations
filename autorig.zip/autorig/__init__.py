# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "AutoRig",
    "description": "",
    "author": "R60D",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math
import mathutils


###############   INITALIZE VARIABLES
autorig = {
    "string": "", 
    "newvector": [], 
    "newvector2": [], 
    "tempx": [], 
    "active_armature": None, 
    "plane": None, 
    "core": None, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   AutoRig
def set_3d_cursor(vector, vector2, vector3, ):
    try:
        sn_cast_blend_data(bpy.context.scene.cursor).location=tuple(mathutils.Vector(vector3) + mathutils.Vector(tuple(mathutils.Vector(vector) + mathutils.Vector(vector2))))
        sn_cast_blend_data(bpy.context.scene.cursor).rotation_quaternion=(0.0, 0.0, 0.0, 0.0)
        sn_cast_blend_data(bpy.context.scene.cursor).rotation_axis_angle=(0.0, 0.0, 0.0, 0.0)
        sn_cast_blend_data(bpy.context.scene.cursor).rotation_euler=(0.0, 0.0, 0.0)
        sn_cast_blend_data(bpy.context.scene.cursor).matrix=0.0
    except Exception as exc:
        print(str(exc) + " | Error in function Set 3D cursor")

def new_string_new_vector(string, initial_vector, ):
    try:
        if r"lowerArm" in sn_cast_string(string):
            function_return_CCD52 = vector_to_list(tuple(mathutils.Vector(initial_vector) * mathutils.Vector((-1.0, -1.0, -1.0))), )
        else:
            if r"knee" in sn_cast_string(string):
                function_return_4D6FA = vector_to_list(tuple(mathutils.Vector(initial_vector) * mathutils.Vector((1.0, 1.0, 1.0))), )
            else:
                function_return_E4FC4 = vector_to_list((0.0, 0.0, 0.0), )
        if (r"lowerArm" in sn_cast_string(string) or r"knee" in sn_cast_string(string)):
            autorig["string"] = r"POLE"
        else:
            autorig["string"] = r"IK"
        function_return_CADC7 = list_to_vector(autorig["newvector"], True, )
        return autorig["string"], function_return_CADC7[0], 
    except Exception as exc:
        print(str(exc) + " | Error in function New String New Vector")

def create_new_bone_with_offset_relative(from_this_bone, name, vector, ):
    try:
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
        for_node_C77E6 = 0
        for_node_index_C77E6 = 0
        for for_node_index_C77E6, for_node_C77E6 in enumerate(bpy.context.active_object.data.bones):
            if for_node_C77E6 == from_this_bone:
                function_return_52356 = set_3d_cursor(vector, for_node_C77E6.head_local, sn_cast_blend_data(bpy.context.active_object).location, )
                bpy.ops.armature.bone_primitive_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',name=name,)
                return name, 
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function Create new bone with offset relative")

def vector_to_list(vector, ):
    try:
        autorig["newvector"] = [vector[0], vector[1], vector[2], ]
    except Exception as exc:
        print(str(exc) + " | Error in function Vector to List")

def initial_offset(enum, distance, ):
    try:
        if r"X" in sn_cast_string(enum):
            autorig["newvector2"] = sn_cast_list(tuple(mathutils.Vector((1.0, 0.0, 0.0)) * mathutils.Vector((distance,distance,distance,))))
        else:
            if r"Y" in sn_cast_string(enum):
                autorig["newvector2"] = sn_cast_list(tuple(mathutils.Vector((0.0, 1.0, 0.0)) * mathutils.Vector((distance,distance,distance,))))
            else:
                autorig["newvector2"] = sn_cast_list(tuple(mathutils.Vector((0.0, 0.0, 1.0)) * mathutils.Vector((distance,distance,distance,))))
        function_return_3C75C = list_to_vector(autorig["newvector2"], not r"_minus" in sn_cast_string(enum), )
        return function_return_3C75C[0], 
    except Exception as exc:
        print(str(exc) + " | Error in function INITIAL offset")

def list_to_vector(list, negate, ):
    try:
        autorig["tempx"] = list
        if negate:
            autorig["tempx"] = [(sn_cast_float(autorig["tempx"][0]) * -1.0), (sn_cast_float(autorig["tempx"][1]) * -1.0), (sn_cast_float(autorig["tempx"][2]) * -1.0), ]
        else:
            pass
        return (sn_cast_float(autorig["tempx"][0]),sn_cast_float(autorig["tempx"][1]),sn_cast_float(autorig["tempx"][2]),), 
    except Exception as exc:
        print(str(exc) + " | Error in function List to Vector")

def set_iks():
    try:
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
        bpy.ops.armature.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
        bpy.ops.armature.symmetrize('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',direction=sn_cast_enum(r"NEGATIVE_X", [("NEGATIVE_X","-X to +X",""),("POSITIVE_X","+X to -X",""),]),)
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"POSE", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
        for_node_7D75B = 0
        for_node_index_7D75B = 0
        for for_node_index_7D75B, for_node_7D75B in enumerate(bpy.context.active_object.pose.bones):
            for_node_9C582 = 0
            for_node_index_9C582 = 0
            for for_node_index_9C582, for_node_9C582 in enumerate([r"bip_foot_R", r"bip_hand_R", ]):
                if for_node_9C582 == for_node_7D75B.name:
                    run_function_on_3802C = for_node_7D75B.constraints.new(type=sn_cast_enum(r"IK", [("CAMERA_SOLVER","Camera Solver",""),("FOLLOW_TRACK","Follow Track",""),("OBJECT_SOLVER","Object Solver",""),("COPY_LOCATION","Copy Location","Copy the location of a target (with an optional offset), so that they move together"),("COPY_ROTATION","Copy Rotation","Copy the rotation of a target (with an optional offset), so that they rotate together"),("COPY_SCALE","Copy Scale","Copy the scale factors of a target (with an optional offset), so that they are scaled by the same amount"),("COPY_TRANSFORMS","Copy Transforms","Copy all the transformations of a target, so that they move together"),("LIMIT_DISTANCE","Limit Distance","Restrict movements to within a certain distance of a target (at the time of constraint evaluation only)"),("LIMIT_LOCATION","Limit Location","Restrict movement along each axis within given ranges"),("LIMIT_ROTATION","Limit Rotation","Restrict rotation along each axis within given ranges"),("LIMIT_SCALE","Limit Scale","Restrict scaling along each axis with given ranges"),("MAINTAIN_VOLUME","Maintain Volume","Compensate for scaling one axis by applying suitable scaling to the other two axes"),("TRANSFORM","Transformation","Use one transform property from target to control another (or same) property on owner"),("TRANSFORM_CACHE","Transform Cache","Look up the transformation matrix from an external file"),("CLAMP_TO","Clamp To","Restrict movements to lie along a curve by remapping location along curve's longest axis"),("DAMPED_TRACK","Damped Track","Point towards a target by performing the smallest rotation necessary"),("IK","Inverse Kinematics","Control a chain of bones by specifying the endpoint target (Bones only)"),("LOCKED_TRACK","Locked Track","Rotate around the specified ('locked') axis to point towards a target"),("SPLINE_IK","Spline IK","Align chain of bones along a curve (Bones only)"),("STRETCH_TO","Stretch To","Stretch along Y-Axis to point towards a target"),("TRACK_TO","Track To","Legacy tracking constraint prone to twisting artifacts"),("ACTION","Action","Use transform property of target to look up pose for owner from an Action"),("ARMATURE","Armature","Apply weight-blended transformation from multiple bones like the Armature modifier"),("CHILD_OF","Child Of","Make target the 'detachable' parent of owner"),("FLOOR","Floor","Use position (and optionally rotation) of target to define a 'wall' or 'floor' that the owner can not cross"),("FOLLOW_PATH","Follow Path","Use to animate an object/bone following a path"),("PIVOT","Pivot","Change pivot point for transforms (buggy)"),("SHRINKWRAP","Shrinkwrap","Restrict movements to surface of target mesh"),]), )
                    run_function_on_3802C.target = bpy.context.active_object
                    run_function_on_3802C.pole_target = bpy.context.active_object
                    run_function_on_3802C.subtarget = sn_cast_string([r"IK_foot_R", r"IK_hand_R", ][for_node_index_9C582])
                    run_function_on_3802C.pole_subtarget = sn_cast_string([r"POLE_knee_R", r"POLE_lowerArm_R", ][for_node_index_9C582])
                    run_function_on_3802C.orient_weight = 0.009999999776482582
                    run_function_on_3802C.chain_count = 3
                else:
                    pass
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
        bpy.ops.armature.select_all('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
        bpy.ops.armature.symmetrize('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',direction=sn_cast_enum(r"NEGATIVE_X", [("NEGATIVE_X","-X to +X",""),("POSITIVE_X","+X to -X",""),]),)
    except Exception as exc:
        print(str(exc) + " | Error in function Set IKS")

def bone_grouper():
    try:
        autorig["active_armature"] = bpy.context.active_object
        bpy.ops.mesh.primitive_plane_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',size=2.0,calc_uvs=True,enter_editmode=False,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(15.0, 15.0, 15.0),)
        autorig["plane"] = bpy.context.active_object
        bpy.context.view_layer.objects.active=autorig["active_armature"]
        for_node_DD3B6 = 0
        for_node_index_DD3B6 = 0
        for for_node_index_DD3B6, for_node_DD3B6 in enumerate([r"bip_foot_R", r"bip_knee_R", r"bip_lowerArm_R", r"bip_hand_R", ]):
            function_return_E4216 = initial_offset(bpy.context.scene.facing, 20.0, )
            function_return_4A682 = new_string_new_vector(for_node_DD3B6, function_return_E4216[0], )
            function_return_E2F12 = create_new_bone_with_offset_relative(bpy.context.active_object.data.bones[sn_cast_string(for_node_DD3B6)], (function_return_4A682[0] + r"_" + sn_cast_string(sn_cast_string(for_node_DD3B6).split(r"_")[1]) + r"_R"), function_return_4A682[1], )
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"POSE", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
            if not bpy.context.active_object.pose.bone_groups.find(r"IK") != -1:
                run_function_on_41DBA = bpy.context.active_object.pose.bone_groups.new(name=r"IK", )
                run_function_on_41DBA.color_set=sn_cast_enum(r"THEME01", [("DEFAULT","Default Colors",""),("THEME01","01 - Theme Color Set",""),("THEME02","02 - Theme Color Set",""),("THEME03","03 - Theme Color Set",""),("THEME04","04 - Theme Color Set",""),("THEME05","05 - Theme Color Set",""),("THEME06","06 - Theme Color Set",""),("THEME07","07 - Theme Color Set",""),("THEME08","08 - Theme Color Set",""),("THEME09","09 - Theme Color Set",""),("THEME10","10 - Theme Color Set",""),("THEME11","11 - Theme Color Set",""),("THEME12","12 - Theme Color Set",""),("THEME13","13 - Theme Color Set",""),("THEME14","14 - Theme Color Set",""),("THEME15","15 - Theme Color Set",""),("THEME16","16 - Theme Color Set",""),("THEME17","17 - Theme Color Set",""),("THEME18","18 - Theme Color Set",""),("THEME19","19 - Theme Color Set",""),("THEME20","20 - Theme Color Set",""),("CUSTOM","Custom Color Set",""),])
                run_function_on_B35F9 = bpy.context.active_object.pose.bone_groups.new(name=r"IKPOLES", )
                run_function_on_B35F9.color_set=sn_cast_enum(r"THEME02", [("DEFAULT","Default Colors",""),("THEME01","01 - Theme Color Set",""),("THEME02","02 - Theme Color Set",""),("THEME03","03 - Theme Color Set",""),("THEME04","04 - Theme Color Set",""),("THEME05","05 - Theme Color Set",""),("THEME06","06 - Theme Color Set",""),("THEME07","07 - Theme Color Set",""),("THEME08","08 - Theme Color Set",""),("THEME09","09 - Theme Color Set",""),("THEME10","10 - Theme Color Set",""),("THEME11","11 - Theme Color Set",""),("THEME12","12 - Theme Color Set",""),("THEME13","13 - Theme Color Set",""),("THEME14","14 - Theme Color Set",""),("THEME15","15 - Theme Color Set",""),("THEME16","16 - Theme Color Set",""),("THEME17","17 - Theme Color Set",""),("THEME18","18 - Theme Color Set",""),("THEME19","19 - Theme Color Set",""),("THEME20","20 - Theme Color Set",""),("CUSTOM","Custom Color Set",""),])
            else:
                pass
            if r"POLE" in function_return_E2F12[0]:
                bpy.context.active_object.pose.bones[function_return_E2F12[0]].custom_shape=autorig["plane"]
                bpy.context.active_object.pose.bones[function_return_E2F12[0]].custom_shape_transform=None
                bpy.context.active_object.pose.bones[function_return_E2F12[0]].bone_group=run_function_on_B35F9
            else:
                bpy.context.active_object.pose.bones[function_return_E2F12[0]].custom_shape=autorig["plane"]
                bpy.context.active_object.pose.bones[function_return_E2F12[0]].custom_shape_transform=None
                bpy.context.active_object.pose.bones[function_return_E2F12[0]].bone_group=run_function_on_41DBA
    except Exception as exc:
        print(str(exc) + " | Error in function Bone grouper")

def core_spawner():
    try:
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
        function_return_04558 = set_3d_cursor((0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0), )
        bpy.ops.armature.bone_primitive_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',name=r"Core",)
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=True,)
        autorig["core"] = bpy.context.active_object.data.edit_bones[r"Core"]
        for_node_FE256 = 0
        for_node_index_FE256 = 0
        for for_node_index_FE256, for_node_FE256 in enumerate([r"POLE", r"IK", ]):
            function_return_CE945 = set_bone_parent(autorig["core"].name, for_node_FE256, )
    except Exception as exc:
        print(str(exc) + " | Error in function Core spawner")

def set_bone_parent(parent, name_reqs, ):
    try:
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw Mode","Paint Grease Pencil Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),]),toggle=False,)
        for_node_04B58 = 0
        for_node_index_04B58 = 0
        for for_node_index_04B58, for_node_04B58 in enumerate(bpy.context.active_object.data.bones):
            if sn_cast_string(name_reqs) in for_node_04B58.name:
                for_node_04B58.parent.name=sn_cast_string(parent)
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function Set bone parent")


###############   EVALUATED CODE
#######   AutoRig
class SNA_PT_AutoRig_0A12B(bpy.types.Panel):
    bl_label = "AutoRig"
    bl_idname = "SNA_PT_AutoRig_0A12B"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in AutoRig panel header")

    def draw(self, context):
        try:
            layout = self.layout
            layout.prop(bpy.context.scene,'facing',icon_value=0,text=r"Facing",emboss=True,expand=False,)
            op = layout.operator("sna.test",text=r"AutoRig!",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in AutoRig panel")


class SNA_OT_Test(bpy.types.Operator):
    bl_idname = "sna.test"
    bl_label = "Test"
    bl_description = "Test"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_A7CD7 = bone_grouper()
            function_return_68649 = set_iks()
            function_return_11B94 = core_spawner()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Test")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Test")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.autorig_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.autorig_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.autorig_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.facing = bpy.props.EnumProperty(name='Facing',description='',options=set(),items=[('X', 'X', 'X'), ('Y', 'Y', 'Y'), ('Z', 'Z', 'Z'), ('X_minus', 'X_minus', 'X-'), ('Y_minus', 'Y_minus', 'Y-'), ('Z_minus', 'Z_minus', 'Z-')])

def sn_unregister_properties():
    del bpy.types.Scene.facing


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_AutoRig_0A12B)
    bpy.utils.register_class(SNA_OT_Test)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Test)
    bpy.utils.unregister_class(SNA_PT_AutoRig_0A12B)